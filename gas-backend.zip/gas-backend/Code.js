function doGet() {
  const sheet = SpreadsheetApp.openById('<SPREADSHEET_ID>').getSheetByName('Sheet1');
  const data = sheet.getDataRange().getValues();
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  const payload = JSON.parse(e.postData.contents);
  const { nama, email, pesan } = payload;
  const sheet = SpreadsheetApp.openById('<SPREADSHEET_ID>').getSheetByName('Sheet1');
  sheet.appendRow([nama, email, pesan]);
  return ContentService.createTextOutput(JSON.stringify({ status: 'success' }))
    .setMimeType(ContentService.MimeType.JSON);
}
